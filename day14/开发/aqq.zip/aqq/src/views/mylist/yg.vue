<template>
  <div>
    <mheader />

    <mlist />


  </div>
</template>

<script>
// import mheader from '@/components/'
import { mapActions, mapMutations, mapState } from "vuex"

import * as API from "@/utils/http"
import mheader from "../../components/ygym/mheader.vue"
import mlist from "../../components/ygym/mlist.vue"
export default {
  data() {
    return {
      // params: {
      //   page: 1,
      //   size: 10
      // },
      // mylist: [],
      // total: 0
    }
  },
  created() {
    // this.getll()
  },
  methods: {

    // getll() {
      // API.yglbapi(this.params).then((res) => {
      //   console.log(this.params,'params');
      //   // console.log(res)
      //   this.mylist = res.data.rows
      //   this.total = res.data.total
      // })
    // },
 
  },
  computed: {
    ...mapState("worker", ["qwe", "mylist", "total"])

  },
  components: {
    mheader,
    mlist
  },
  filters: {},
  watch: {}
}
</script>

<style lang="scss" scoped></style>