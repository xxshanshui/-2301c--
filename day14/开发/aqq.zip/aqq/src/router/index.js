import Vue from "vue"
import VueRouter from "vue-router"
import HomeView from "../views/HomeView.vue"
import { getToken } from "../utils/cookejs"

Vue.use(VueRouter)
export const ly =
  [
    {
      path: "/shouye",
      name: "shouye",
      meta: { title: '首页' },
      component: () => import("../views//mylist/shouye.vue")
    },
    {
      path: "/zzjg",
      name: "zzjg",
      meta: { title: '组织架构' },
      component: () => import("../views/mylist/zzjg.vue")
    },
    {
      path: "/qx",
      name: "qx",
      meta: { title: '权限管理' },
      component: () => import("../views/mylist/qx.vue")
    },
    {
      path: "/yg",
      name: "yg",
      meta: { title: '' },
      meta: { title: '员工' },
      component: () => import("../views/mylist/yg.vue"),
      children:[
        {
          path: "/yg/ygck",
          name: "yg/ygck",
          component: () => import("../views/mylist/ygck.vue")
        }
      ]
    },
 
    {
      path: "/gssz",
      name: "gssz",
      meta: { title: '公司设置' },
      component: () => import("../views/mylist/gssz.vue")

    },
    // 社保
    {
      path: "/social_securitys",
      name: "social_securitys",
      meta: { title: '社保' },
      component: () => import("../views/mylist/social_securitys.vue")

    },
    // 审批
    {
      path: "/approvals",
      name: "approvals",
      meta: { title: '审批' },
      component: () => import("../views/mylist/approvals.vue")

    },
    // 考勤
    {
      path: "/attendances",
      name: "attendances",
      meta: { title: '考勤' },
      component: () => import("../views/mylist/attendances.vue")

    },
    // 工资
    {
      path: "/salarys",
      name: "salarys",
      meta: { title: '工资' },
      component: () => import("../views/mylist/salarys.vue")

    },

  ]
const routes = [
  {
    path: "/",
    name: "home",
    component: HomeView,
    redirect: '/shouye',
     children: ly,
  },
  {
    path: "/about",
    name: "about",
    component: () => import("../views/AboutView.vue")
  },
  {
    path: "/login",
    name: "login",
    component: () => import("../views/Login.vue")
  },

]

const router = new VueRouter({
  routes
})

router.beforeEach((to, from, next) => {
  let tokens = getToken()
  if (tokens && to.path == "/login") {
    next("/")
  } else if (!tokens && to.path != "/login") {
    next("/login")
  } else {
    next()
  }
})

export default router
