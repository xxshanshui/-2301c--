<template>
  <div>
    <!-- <div class="daz"> -->
    <img class="img" src="../assets/logo.png" alt="" />
    <el-menu
      default-active="1-4-1"
      class="el-menu-vertical-demo"
      text-color="#fff"
      background-color="transparent"
      router
      :collapse="isCollapse"
    >
      <el-menu-item :index="item.path" v-for="item in qqq">
        <!-- <i class="iconfont icon-yibiaopan"></i> -->
        <i class="el-icon-setting"></i>

        <span slot="title">{{ item.meta.title }}</span>
      </el-menu-item>
    </el-menu>
    <!-- </div> -->
  </div>
</template>

<script>
import { ly } from "@/router/index"
export default {
  props: ["isCollapse"],
  data() {
    return {
      qqq:[]
    }
  },
  methods: {},
  computed: {},
  filters: {},
  watch: {},
  created(){
    console.log(ly,'eqweqwewqeqw');
    this.qqq= ly
  }
}
</script>

<style lang="scss" scoped>
.el-menu {
  color: #fff;
  i {
    color: #fff;
    font-size: 25px;
    margin-right: 10px;
  }
}

.img {
  margin: 10px 20%;
  width: 50%;
  height: 32px;
}
.el-menu-item:hover {
  color: #4777fa !important;
  i {
    color: #4777fa !important;
  }
}
</style>
