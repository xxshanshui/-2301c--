<template>
  <div>
    <el-table
      ref="singleTable"
      :data="mylist"
      highlight-current-row
      style="width: 100%; margin-top: 20px; box-shadow: 0 0 5px gray"
    >
      <el-table-column type="index" label="序号" width="50">
        <template slot-scope="scope">
          {{ (qwe.page - 1) * qwe.size + scope.$index + 1 }}
        </template>
      </el-table-column>
      <el-table-column property="username" label="姓名" width="120"> </el-table-column>
      <el-table-column property="staffPhoto" label="头像" width="120">
        <img style="width: 50px" src="https://ihrm.itheima.net/static/img/bigUserHeader.fda3837f.png" alt="" />
      </el-table-column>
      <el-table-column property="mobile" label="手机号"> </el-table-column>
      <el-table-column property="workNumber" label="工号"> </el-table-column>
      <el-table-column property="formOfEmployment" label="聘用形式"
        >{{ "formOfEmployment" == "1" ? "非正式" : "正式" }}
      </el-table-column>
      <el-table-column property="departmentName" label="部门"> </el-table-column>
      <el-table-column property="correctionTime" label="入职时间"> </el-table-column>
      <el-table-column property="enableState" label="账户状态">
        <template slot-scope="scope">
          <el-switch
            v-model="scope.row.enableState"
            active-color="#13ce66"
            inactive-color="#ff4949"
            :active-value="1"
            :inactive-value="0"
          >
          </el-switch>
        </template>
      </el-table-column>
      <el-table-column label="操作" style="display: flex">
        <template slot-scope="scope">
          <a style="margin-left: 10px; color: #409eff" @click="zn(scope.row.id)">查看</a>
          <a style="margin-left: 10px; color: #409eff">转正</a>
          <a style="margin-left: 10px; color: #409eff">调岗</a>
          <a style="margin-left: 10px; color: #409eff">离职</a>
          <a style="margin-left: 10px; color: #409eff" @click="js(scope.row.id)">角色</a>
          <a style="margin-left: 10px">删除</a>
        </template>
      </el-table-column>
    </el-table>

    <!-- 模态框 -->
    <el-dialog title="分配角色" :visible.sync="dialogVisible" width="50%">
      <!-- <div style="display: flex;">
        <div v-for="item in checkList" :key="item.id">
        <el-checkbox-group v-model="checkList">
    <el-checkbox label="">{{ item.name }}</el-checkbox>
  </el-checkbox-group>
</div>

    </div> -->
      <el-tree :data="mylistt" :props="props" lazy show-checkbox> </el-tree>
      <div style="margin-top: 40px; text-align: center">
        <el-button type="primary" @click="qd">确定</el-button>
        <el-button @click="qx">取消</el-button>
      </div>
    </el-dialog>
    <!-- 分页 -->
    <el-pagination
      @size-change="chengesize"
      @current-change="chengepage"
      :current-page.sync="qwe.page"
      :page-size.sync="qwe.size"
      background
      layout="prev, pager, next"
      :total="total"
    >
    </el-pagination>
  </div>
</template>

<script>
import { mapActions, mapMutations, mapState } from "vuex"
import { del } from "vue"
import { changeData } from "@/utils/dg"
import * as API from "@/utils/http"
export default {
  data() {
    return {
      props: {
        label: "name",
        children: "children"
      },
      // flag: false,
      // flag1: false,
      // flag2: false,
      // flag3: false,
      // flag4: false,
      dialogVisible: false,
      // listjs: [],
      mylistt: []
      // checkList: [],
      // qwe:{
      //   id: "",
      //   permIds:""
      // }
    }
  },
  methods: {
    ...mapActions("worker", ["getyg"]),
    ...mapMutations("worker", ["chengepage1", "chengesize1"]),

    chengepage(val) {
      this.chengepage1(val)
      this.getyg()
    },
    chengesize(val) {
      this.chengesize1(val)
      this.getyg()
    },
    // ...mapMutations('worker',[]),
    // 查看
    zn(id) {
      console.log(id, "9999999999999999999")
      this.$router.push({
        path: "/ygck",
        query: { id: id }
      })
    },

    async js(id) {
      // this.qwe.id=id
      // this.dialogVisible = true
      // API.ygjsapi(this.params).then((res) => {
      //   console.log(res)
      //   this.form = res.data
      // })
      this.dialogVisible = true
      if (await (await API.qxsjapi()).success) {
        let res = await (await API.qxsjapi()).data
        this.mylistt = changeData(res, "0")
        console.log(this.mylistt)
        // this.form= res
      }
      API.gshtapi({ id: id }).then((res) => {
        console.log(res)
        this.form = res.data
      })
    },
    qd() {
      API.gsfpapi(this.qwe).then((res) => {
        console.log(res)
      })
      this.dialogVisible = false
    },
    qx() {
      this.dialogVisible = false
    }
  },
  computed: {
    ...mapState("worker", ["qwe", "mylist", "total"])
  },
  mounted() {
    this.getyg()
  },

  components: {},
  filters: {},
  watch: {}
}
</script>

<style lang="scss" scoped>
.q {
  color: #66b1ff;
}

.qq {
  // color: #66B1FF;
}
</style>
