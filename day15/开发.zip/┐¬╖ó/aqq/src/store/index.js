import Vue from "vue"
import Vuex from "vuex"
import worker from "./worker"
import muea from "./muea"
import getters from "./getters"
Vue.use(Vuex)

export default new Vuex.Store({
  state: {},
  getters: {},
  mutations: {},
  actions: {},

  modules: {
    worker,
    muea,
    getters
  }
})
