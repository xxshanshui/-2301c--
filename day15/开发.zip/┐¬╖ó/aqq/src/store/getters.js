const getters = {
    menuNewList: (state) => state.menuList.qwe,

    btnPermission: (state) => state.menuList.ygbs
}

export default getters