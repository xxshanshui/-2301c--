import { yglbapi } from '@/utils/http'

const state = {
    mylist: [],
    total: 0,
    qwe: {
        page: 1,
        size: 10
    }


}
const mutations = {
    getlist(state, obj) {
        state.mylist = obj.data.rows
        state.total = obj.data.total
        console.log(obj, '12313132123');
    },
    chengepage1(state,val) {
        state.qwe.page = val
    },
    chengesize1(state,val) {
        state.qwe.size = val
    }



}
const actions = {
    async getyg({ commit, state }) {
        let res = await yglbapi(state.qwe)
        commit('getlist', res)
    }



}

const getters = {

}

export default {
    namespaced: true,
    state,
    actions,
    mutations
}