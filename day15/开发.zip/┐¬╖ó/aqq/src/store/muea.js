import { queryhpage, qxsjapi } from '@/utils/http'


const state = {
    list: [],
    list1: [],
    qwe: [],
    //员工页面按钮标识
    ygbs: []

}
const mutations = {
    get(state, data) {
        state.list1 = data.data
    },
    getma(state, data) {
        state.list = data.data.roles.menus
        state.ygbs = ["employees:add", "employees:list", "employees:info", "employees:daochu"]
    },
    qwelist(state, played) {
        console.log(played)
        const {
            alliMenlist,
            singleList: { data }
        } = played
        const { menus } = alliMenlist.data.roles
        state.qwe = data.filter((item) => {
            return menus.filter((element) => element === item.code).length > 0
        })
        console.log(state.qwe, "新数组")
    }
}
const actions = {
    async getlist({ commit }) {
        const alliMenlist = await queryhpage()
        const singleList = await qxsjapi()
        commit('qwelist', { alliMenlist, singleList })
        commit('getma', alliMenlist)
        commit('get', alliMenlist)


    },
}

export default { namespaced: true, state, mutations, actions }