<template>
  <div style="margin-right: 20px;" @click="fangda">
    <svg-icon :icon-class="isfull ? 'suoxiao' : 'fangda'"> </svg-icon>
  </div>
</template>

<script>
import screenfull from "screenfull"

export default {
  data() {
    return {
      isfull: false
    }
  },
  methods: {
    fangda() {
      screenfull.toggle()
      if (screenfull.isEnabled) {
        screenfull.on("change", () => {
          this.isfull = screenfull.isFullscreen
          console.log(this.isfull)
        })
      }
    }
  },
  computed: {},
  filters: {},
  watch: {},
  destroyed() {
    screenfull.off("change", () => {
      console.log("销毁")
    })
  }
}
</script>

<style lang="scss" scoped></style>
