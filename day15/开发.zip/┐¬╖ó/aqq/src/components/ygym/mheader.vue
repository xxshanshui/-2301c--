<template>
  <div>
    <div
      style="height: 70px; line-height: 70px; display: flex; justify-content: space-between; box-shadow: 0 0 5px gray"
    >
      <div>
        <el-button type="primary" plain style="margin-left: 10px">!共16条记录</el-button>
      </div>
      <div style="margin-right: 10px">
        <el-button size="small" v-if="isAuth('employees:ooo')" type="danger" @click="exportData"
          >简单表头导出</el-button
        >
        <el-button size="small" type="info">复杂表头导出</el-button>
        <el-button size="small" type="success" @click="$router.push('/import')">excel导入</el-button>
        <el-button size="small" type="primary" @click="showDialog = true">新增员工</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import { xlsx } from "@/utils/xlsx"
import { mapActions, mapGetters } from "vuex"
// import EmployeeEnum from "@/api/constant/employees" // 引入枚举对象

export default {
  data() {
    return {
      // EmployeeEnum,
      listHander: {
        username: "姓名",
        mobile: "手机号",
        workNumber: "工号",
        formOfEmployment: "聘用形式",
        departmentName: "部门",
        timeOfEntry: "入职时间",
        enableState: "用户状态"
      }
    }
  },
  methods: {
    ...mapActions("worker", ["getUserListInfo"]),
    exportData() {
      xlsx(this.workertableList, this.listHander, "人资列表下载")
    }
  },
  computed: {
    ...mapGetters(["workerTotal", "workertableList"])
  },
  components: {},
  filters: {},
  watch: {},
  mounted() {
    this.getUserListInfo()
  }
}
</script>

<style lang="scss" scoped></style>
