<template>
  <div></div>
</template>

<script>
export default {
  data() {
    return {}
  },
  methods: {},
  created() {
    // this.$http
    //   .post(this.$http.addurl("/sys/login"), {
    //     mobile: "17764049967",
    //     password: 123456
    //   })
    //   .then((res) => {
    //     console.log(res)
    //   })
    //   .catch((err) => {
    //     console.log(err)
    //   })
  }
}
</script>

<style lang="scss" scoped></style>
