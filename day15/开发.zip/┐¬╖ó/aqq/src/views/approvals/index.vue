<template>
    <div>
        <h1>审批</h1>
    </div>
</template>

<script>
export default {
 data() {
     return {};
 },
 methods: {},
 computed: {},
 components: {},
 filters: {},
 watch: {},
};
</script>

<style lang="scss" scoped>

</style>