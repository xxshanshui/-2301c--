import Vue from "vue"
import VueRouter from "vue-router"
import HomeView from "../views/HomeView.vue"
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { getToken } from "../utils/cookejs"
// import layout from "../layout"
import store from "@/store"
Vue.use(VueRouter)

store.dispatch("muea/getlist")




// export const ly =
//   [
//     {
//       path: "/shouye",
//       name: "shouye",
//       meta: { title: '首页' },
//       component: () => import("../views//mylist/shouye.vue")
//     },
//     {
//       path: "/zzjg",
//       name: "zzjg",
//       meta: { title: '组织架构' },
//       component: () => import("../views/mylist/zzjg.vue")
//     },
//     {
//       path: "/qx",
//       name: "qx",
//       meta: { title: '权限管理' },
//       component: () => import("../views/mylist/qx.vue")
//     },
//     {
//       path: "/yg",
//       name: "yg",
//       meta: { title: '' },
//       meta: { title: '员工' },
//       component: () => import("../views/mylist/yg.vue"),
//       children: [
//         {
//           path: "/yg/ygck",
//           name: "yg/ygck",
//           component: () => import("../views/mylist/ygck.vue")
//         }
//       ]
//     },

//     {
//       path: "/gssz",
//       name: "gssz",
//       meta: { title: '公司设置' },
//       component: () => import("../views/mylist/gssz.vue")

//     },
//     // 社保
//     {
//       path: "/social_securitys",
//       name: "social_securitys",
//       meta: { title: '社保' },
//       component: () => import("../views/mylist/social_securitys.vue")

//     },
//     // 审批
//     {
//       path: "/approvals",
//       name: "approvals",
//       meta: { title: '审批' },
//       component: () => import("../views/mylist/approvals.vue")

//     },
//     // 考勤
//     {
//       path: "/attendances",
//       name: "attendances",
//       meta: { title: '考勤' },
//       component: () => import("../views/mylist/attendances.vue")

//     },
//     // 工资
//     {
//       path: "/salarys",
//       name: "salarys",
//       meta: { title: '工资' },
//       component: () => import("../views/mylist/salarys.vue")

//     },

//   ]
export const routes = [
  {
    path: "/login",
    name: "login",
    component: () => import("../views/Login.vue")
  },
  {
    path: "/",
    name: "home",
    redirect: '/shouye',
    component: HomeView,
    children: [
      {
        path: "shouye",
        name: "shouye",
        component: () => import("@/views/dashboard/index.vue"),
        meta: { title: "首页", icon: "menu", isAthoout: false }
      }
    ]
  },
  {
    path: "/about",
    name: "about",
    component: () => import("../views/AboutView.vue")
  },


]

const Dashboard = {
  path: "shouye",
  name: "shouye",
  component: () => import("@/views/dashboard/index.vue"),
  meta: { title: "首页", icon: "menu", isAthoout: false }
}

const createRouter = () => new VueRouter({
  routes
})
const router = createRouter()



router.beforeEach((to, from, next) => {

  const tokens = getToken()
  if (tokens && to.path == "/login") {
    next("/")
  } else if (!tokens && to.path != "/login") {
    next("/login")
  } else {
    next()
  }

  NProgress.start()
  // console.log(store)
  setTimeout(() => {
    // console.log(store.qwe, "store.getters.menuNewList")
    const initDynamic = store.state.muea.qwe
    const Dynamic = []
    initDynamic.forEach((child) => {
      const item = {
        path: "/" + child.code,
        name: child.code,
        component: () => import(`@/views/${child.code}/index.vue`),
        meta: {
          icon: 'shouye',
          title: child.name
        }
      }
      router.addRoute('home', item)
      Dynamic.push(item)
    })
    Dynamic.unshift(Dashboard)
    localStorage.setItem('Route', JSON.stringify(Dynamic))
  }, 1000)
  next()
})
router.afterEach(() => {
  NProgress.done()
})



export default router
